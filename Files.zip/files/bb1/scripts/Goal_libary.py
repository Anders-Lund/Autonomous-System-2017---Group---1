#!/usr/bin/env python

# import libaries 
import rospy
 
import actionlib
 
import tf
 
import geometry_msgs.msg
 
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
 
from std_msgs.msg import String
 
from std_msgs.msg import Float64
  
from geometry_msgs.msg import TransformStamped

from Robot import bb1Robot



# initialise variables

positionX = 0.0
 
positionY = 0.0
 
positionZ = 0.0
 
positionQX = 0.0
 
positionQY = 0.0
 
positionQZ = 0.0

# In quaternions, the w may not be 0 or close to 0, so the variable is hardcoded to 1.0
 
positionQW = 1.0
 
waypoints = [[(positionX,positionY,positionZ),(positionQX,positionQY,positionQZ,positionQW)]]  
 
# get information as a string from the 'Get_string_from_Convert_name_to_location' function
def callback(msg):


  global positionX, positionY, positionZ, positionQX, positionQY, positionQZ, positionQW, waypoints

  # Split up the string to retreive the information needed.

  print 'something'
  positions = msg

  positions = str(positions).split(',')
  
  positionX = positions[1].strip('(')
  
  positionY = positions[2]
 
  positionZ = positions[3]
            
  positionQX = positions[4]
 
  positionQY = positions[5]
 
  positionQZ = positions[6]
  
  # In quaternions, the w may not be 0 or close to 0, so the variable is hardcoded to 1.0

  positionQW = 1.0

  #Convert the values to a float (a comma number)
  positionX = float(positionX)
  positionY = float(positionY)
  positionZ = float(positionZ)
  positionQX = float(positionQX)
  positionQY = float(positionQY)
  positionQZ = float(positionQZ)

  waypoints = [[(positionX,positionY,positionZ),(positionQX,positionQY,positionQZ,positionQW)]]
   
 
def goal_pose(pose): 

  
    goal_pose = MoveBaseGoal()
    
    goal_pose.target_pose.header.frame_id = '/map'
 
    goal_pose.target_pose.pose.position.x = pose[0][0]
 
    goal_pose.target_pose.pose.position.y = pose[0][1]
 
    goal_pose.target_pose.pose.position.z = pose[0][2]
 
    goal_pose.target_pose.pose.orientation.x = pose[1][0]
 
    goal_pose.target_pose.pose.orientation.y = pose[1][1]
 
    goal_pose.target_pose.pose.orientation.z = pose[1][2]
 
    goal_pose.target_pose.pose.orientation.w = pose[1][3]

    return goal_pose
              
 
def Get_string_from_Convert_name_to_location():
 
  
    #initialise node
    rospy.init_node('Goal_information_for_move_base')
    # Gets the information the Convert_name_to_location is publishing
    # and send it to the function called callback 
    Flag_sub = rospy.Subscriber('/Goal', String, callback)
           
 
if __name__ == '__main__':
 
    # runs the Get_string_from_Convert_name_to_location function
    Get_string_from_Convert_name_to_location()

    # will loop as long as the code is not shutdown / ctl c
    while not rospy.is_shutdown():

      # uses the action libaery
      client = actionlib.SimpleActionClient('move_base', MoveBaseAction)

      client.wait_for_server()

      #sets the information as a goal, using the goal libery
      for pose in waypoints:

        goal = goal_pose(pose)

        client.send_goal(goal)

        # will only run once the code have reached its destination, marking its current task complete
        if client.wait_for_result() == True:

          robot = bb1Robot()
          robot.pp()