#!/usr/bin/env python

#class Products:

#list of products and its correlation to components
from Complist import assembly_station


def Get_components(components):
		# A dictionary of what components there is in a product
		Products_list = {"P1": ["C1","C3","C4","C4"],"P2": ["C1","C2","C5","C6"],"P3": ["C3","C3","C5"],"P4": ["C2","C3","C4"]}

		components_list = []
		if components in Products_list:
			componentsk = Products_list[components] 
			for component in componentsk:
				components_list.append(component) #apppend the components in the product to a list
			transfer = assembly_station()
			transfer.get_component_list(components_list) # send that list to the assembly station
			return components_list

			return components_list



def Components_to_fetch(item): ## checks if the product is in the product list 
		Products_list = {"P1": ["C1","C3","C4","C4"],"P2": ["C1","C2","C5","C6"],"P3": ["C3","C3","C5"],"P4": ["C2","C3","C4"]}
		list_of_Components_to_fetch = []
		for items in Products_list:
			if items == item[0]:
				#if it is in the product list, append to the list of components to get
				list_of_Components_to_fetch = list_of_Components_to_fetch + Get_components(items) 
				
				

class Product:

	def __init__ (self, Product_id, Product_type):
	
		self.id = Product_id
		self.type = Product_type # Product 1, Product 2, Product 3.....
		#self.status = status
		self.component = Components_to_fetch([self.type]) # ask for the product in components
		#self.component_to_fetch
        #self.component = type

if __name__ == '__main__':

   	listen = ["P1"]
   	a = Components_to_fetch(listen)
   	print a 



