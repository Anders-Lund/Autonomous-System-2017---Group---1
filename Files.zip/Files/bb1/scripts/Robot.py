#!/usr/bin/env python

#from Complist import assembly_station

from Convert_name_to_location import location_goal

class bb1Robot:
    # functions: check backpack, set location, pick/place a component

    def __init__(self):
        self.backpack = []
        self.Go_fetch = []

    def check_backpack(self, list): # Receives the list of products the assembly station needs
        self.Go_fetch = list
        if len(self.backpack) < 2:

			# TO DO
				#add a goal priotising algorithm
		
            for items in self.backpack:
                if items in self.Go_fetch:
                    self.Go_fetch.remove(items)	# check what the robot does already have in its backpack
                    break
            set_location = location_goal()
            myrobot = bb1Robot()
			# Sends the location of the first componet that it does not carry, but the assembly_station needs to produce the product
            set_location.Convert_Location_Goal(myrobot.component_locations(self.Go_fetch[0])) 

        else:		# if the robot is full, go to the assembly station
            set_location = location_goal()
            myrobot = bb1Robot()
            set_location.Convert_Location_Goal(myrobot.component_locations('AS'))

    def pp(self): # method runs if the AGV as reached its destination

         if location_request == "'Assembly_Station_Location'": # if that distination was the assembly_station

            Go_to = self.backpack
            app = assembly_station()
            app.appendlist(Go_to) # "give" these items the AGV is carrying to the assembly_station
            self.backpack = [] # removes them from what it is carrying
         else:		# Determine what destination it reached
            ComponentDict = {
                "'/vicon/Flag/Flagsds'": "C1",
                "['Component2_Location']": "C2",
                "['Component3_Location']": "C3",
                "['Component4_Location']": "C4",
                "['Component5_Location']": "C5",
                "['Component6_Location']": "C6"
            }

            for locations in ComponentDict:
               if location_request == locations:
                    self.backpack.append(ComponentDict[locations])	# Add a product with that name to the backpack
               return self.backpack



    def component_locations(self, for_dict):

        component_dict = {'AS': ['Assembly_Station_Location'],
                          'C1': "/vicon/Flag/Flag",
                          'C2': ['Component2_Location'],
                          'C3': ['Component3_Location'],
                          'C4': ['Component4_Location'],
                          'C5': ['Component5_Location'],
                          'C6': ['Component6_Location']
                          }

        if for_dict in component_dict:
            global location_request
            location_request = (str(component_dict[for_dict]))	# converts the component into a location
            return str(component_dict[for_dict])


# Calling a main function for testing purposes
if __name__ == "__main__":
    myrobot = bb1Robot()
    while True:

        myrobot.check_backpack()
        myrobot.pp()
    #print(myrobot.check_backpack())
    """"print(myrobot.check_backpack())
    print("component locations output:")
    print(myrobot.component_locations('AS'))"""
