#!/usr/bin/env python

import rospy

import actionlib

import tf

from geometry_msgs.msg import Twist

import serial

from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal

Data = serial.Serial('/dev/ttyACM0', 115200)

offset = 1.0  #For scaling linear values in the algorithm below
ALG_L = 0.0
ALG_R = 0.0


# Algorithm that calculates values for L and R motor based in data from CMD_VEL:
def alg_run (data):

    LI = data.linear.x #Term defining the angular value from CMD_VEL
    AG = data.angular.z #Term defining the linear value from CMD_VEL

    ALG_L = (LI * offset) + (AG * -0.2)
    ALG_R = (LI * offset) + (AG * 0.2)



    global ALG_L, ALG_R

# The function below converts values from the algorithm into the letters to-be-sent over serial.
def get_speed(ALG_var, capital=True):

    #ARD_speedlist = [-190, -180, -170, -160, -150, -140, -130, -120, -110, -100, -90, -80, 0, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170, 180, 190, 200]
    speedlist = (-1.2, -1.1, -1.0, -0.9, -0.8, -0.7, -0.6, -0.5, -0.4, -0.3, -0.2, -0,1, 0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2)
    LETTERLIST = ('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z' )


    # If the speed is zero, the function explicitely sends a 0 in letter-format.
    if ALG_var == 0.0:
        Char_var = 'M'

    # If the speed is different than zero, the function tests 
	# which of the lower values in the speedlist matches and 
	# extracts the corresponding letter from the LETTERLIST
    else:
        for x in range (len(speedlist)):
            try:
                if speedlist[x]<=ALG_var<=speedlist[x+1]:
                    Char_var = LETTERLIST[x]

                    break
 
            except IndexError:
                print "Index error"
                break



    # If capital is either TRUE or FALSE, the function then specifies if the letter
	# to-be-sent is upper or lower case for LEFT and RIGHT motor respectively.
    if capital==True:
        return Char_var
    
    else:
        return Char_var.lower()


# Function below listens to the cmd_vel from the ros domain:
def getmove():
	
    rospy.init_node('rpi_listener')

    cmd_vel = rospy.Subscriber('/cmd_vel', Twist, alg_run)


# While ROS is active, the code below is publishing the 
# cmd_vel values to the Arduino in the letter formatting:
print "System initialized and ready!"
while not rospy.is_shutdown():
	
    getmove()

	rospy.sleep(0.2)
	ARD_L = get_speed(ALG_L, capital=True)
	Data.write(ARD_L)


	ARD_R = get_speed(ALG_R, capital=False)
	Data.write(ARD_R)



