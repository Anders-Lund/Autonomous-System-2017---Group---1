#!/usr/bin/python
#from Product_list import prod_list

from Robot import bb1Robot

class assembly_station:


    def __init__(self):
        self.P_C = []
    def get_component_list(self, list): 	# imports the list of components to get, in order to make the product
        self.component_list = list
        for items in self.P_C:              # Removes components from the list, if they are already in stock
            if items in self.component_list:
                self.component_list.remove(items)
            if self.component_list == []:	# If all the needed componenets are in stock
               product_done = prod_list()
               product_done.prod_done()		# Call the method Prod_done
        myc_t_f = bb1Robot()
        myc_t_f.check_backpack(self.component_list)

    def appendlist(self, anotherlist):		# Receives the list of components from the robot
        self.Component_fetch = anotherlist

        for item in self.Component_fetch:
            self.P_C.append(item)			# Append that list to the assembly_station's stuck list
        return




    if __name__ == '__main__':

        matchlist()

        appendlist()




