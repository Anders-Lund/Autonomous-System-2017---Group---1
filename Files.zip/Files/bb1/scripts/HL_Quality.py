#!/usr/bin/env python

#This script will handle the High Level commands regarding quality control for the AGV project.
import openpyxl

from openpyxl import load_workbook


#Specify details for address etc. for excel sheet.
#Setup global values such as QC pass, QC fail, waiting status.
#Define function that scans for finished products.

wb = openpyxl.load_workbook('prod_test.xlsx')
sheet = wb.get_sheet_by_name('Sheet1')
for row in range(2, sheet.max_row):
    print('{} {:3} {} {:2} {} {:8} {} {:8}'.format(' Product ID:', sheet.cell(row=row, column=1).value, ' Product type:', sheet.cell(row=row, column=2).value, ' Production status:', sheet.cell(row=row, column=3).value, ' QC status:', sheet.cell(row=row, column=4).value))
print('-----------------------')



prod_defe_text=input('Enter defective product ID: ')
prod_defe=int(prod_defe_text)
for row_edit in range(2, sheet.max_row):
    if sheet.cell(row=row_edit, column=1).value == prod_defe:
        sheet.cell(row=row_edit, column=3).value = 'Waiting'
        sheet.cell(row=row_edit, column=4).value = 'Defect'
        break

wb.save('prod_test.xlsx')
wb.close()

print('{} {} {} {} {}'.format('QC input product ID', prod_defe, 'received and flagged as defect. Product type', sheet.cell(row=row_edit, column=2).value, 'will be produced again!' ))

#Define function that outputs list of products not evaluated by QC
#Define function that takes input from QC and either passes or fails products.
#Create loop that iterates the above function. Decide if this module should be called or iterate continously.



#qc_status()










