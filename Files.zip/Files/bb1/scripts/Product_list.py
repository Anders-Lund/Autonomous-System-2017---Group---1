#!/usr/bin/env python

# Run:
	#sudo apt install python-pip
	#pip install --upgrade pip
	#pip install openpyxl
import openpyxl
from Product import Product

class prod_list:

	def Get_prodution_schedule():

		Read_data = 2

		Daily_Production_Plan = []
		Have_I_Read_the_whole_file = False

		while Have_I_Read_the_whole_file != True:
			workbook = openpyxl.load_workbook('/home/emanuil/catkin_ws/src/bb1/scripts/Daily_Production_Plan.xlsx') # Import production schedule

			Schedule = workbook.get_sheet_by_name('Plan')


			if Schedule.cell(row=Read_data, column=2).value: #if the cell contains a value

					if str(Schedule.cell(row=Read_data, column=3).value) == "Waiting": # find the first product undone
						Daily_Production_Plan.append(Product((Read_data-1), str(Schedule.cell(row=Read_data, column=2).value))) #send that product to the product.py

					else:
						print ("continuing, product ") + str(Schedule.cell(row=Read_data, column=1).value) + " = " + str(Schedule.cell(row=Read_data, column=3).value)
						Read_data = Read_data + 1
					continue


			else:
				Have_I_Read_the_whole_file = True
			
			print ("The Days Work Have Been Completed")
			break

	def prod_done():
		wb = openpyxl.load_workbook('/home/emanuil/catkin_ws/src/bb1/scripts/Daily_Production_Plan.xlsx') # import production schedule
		sheet = wb.get_sheet_by_name('Plan')
		for i in range(2, sheet.max_row):
			if sheet.cell(row=i, column=3).value == "Waiting": 
				sheet.cell(row=i, column=3).value = 'Done'		#marking the product as done
				sheet.cell(row=i, column=4).value = 'Approved'
				print("Product ID",sheet.cell(row=i, column=1).value , "of Product type", sheet.cell(row=i, column=2).value, "has been produced!" )
				break

		wb.save('/home/emanuil/catkin_ws/src/bb1/scripts/Daily_Production_Plan.xlsx')
		wb.close()
 
 	



	if __name__ == "__main__":


    
		Give_me_my_list = Get_prodution_schedule()
		workbook.close()

		#print Give_me_my_list
