#!/usr/bin/env python


# Liberies, probably not all of of them are needed.
 
import rospy
 
import actionlib
 
import tf
 
import geometry_msgs.msg
 
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
 
from std_msgs.msg import String
 
from std_msgs.msg import Float64
 
from geometry_msgs.msg import TransformStamped

import std_msgs.msg

#from Eman import location 


#initialise variables:

class location_goal:


    def __init__(self):
        self.object = "vicon/Flag/Flag"

        

	positionX = 0.0
 
	positionY = 0.0
 
	positionZ = 0.0
 
	positionQX = 0.0
 
	positionQY = 0.0
 
	positionQZ = 0.0

# In quaternions, the w may not be 0 or close to 0, so the variable is hardcoded to 1.0
 
	positionQW = 1.0
 
	position = positionX,positionY,positionZ,positionQX,positionQY,positionQZ,positionQW

# Our publisher expect a string, so the coordinates are converted to one long string.
# It was problamatic to send a list, therefore I am sending list instead.
# The commas are there to help seperate the string back to a list in the "Goal_libary.py"

	position = "," + str(position) + ","

	# The function called in our listener(). The information from from the node that is subscribed to is imported as 'msg'. 
	def callback(msg):

		# The information we receive by subscribing to our location is given by by 3 transform translations and 3 transform rotation.
		# Remove the '#' below to see the information we receive.
		print "Running?"
		s = msg
		print s
		positionX = msg.transform.translation.x
	 
		positionY = msg.transform.translation.y
	 
		positionZ = msg.transform.translation.z
	            
		positionQX = msg.transform.rotation.x
	 
		positionQY = msg.transform.rotation.y
	 
		positionQZ = msg.transform.rotation.z
	 
	 	# In quaternions, the w may not be 0 or close to 0, so the variable is hardcoded to 1.0
		#positionQW = msg.transform.rotation.w
		positionQW = 1.0
	 
		position = positionX,positionY,positionZ,positionQX,positionQY,positionQZ,positionQW

		#Our publisher expect a string, so the coordinates are converted to one long string.
		# It was problamatic to send a list, therefore I am sending list instead.
		# The commas are there to help seperate the string back to a list in the "Goal_libary.py"

		position = "," + str(position) + ","

		# preparing our converted information to be published on the node /Goal as a string
		pub = rospy.Publisher('/Goal', String, queue_size=1)

		# Publish the information
		pub.publish(position)

	def listener():
	 
	  	# Object = the location we are intrested in reaching
	  	# The future plan is to make the variable 'object' dynamic, but for testing purposes it is static
		Object = '/vicon/Flag/Flag'

		# Subscribe to the node defined in the object. In this case the position of the flag in vicon.
		# The message type is a TransformStamp and the information is send to the function called callback.
		Flag_sub = rospy.Subscriber(Object, TransformStamped, callback)

	def Goal():


		#initialise  the Goal node
		rospy.init_node('Goal')
		# Run the listener
		listener()


	def Convert_Location_Goal(location):

			
		# Object = the location we are intrested in reaching
	  	# The future plan is to make the variable 'object' dynamic, but for testing purposes it is static

		Object = location
		print "Me, Mr. Robot, aka the BumbleBee, are driving towards location : " + Object
		# Subscribe to the node defined in the object. In this case the position of the flag in vicon.
		# The message type is a TransformStamp and the information is send to the function called callback.
		flag_sub = rospy.Subscriber(location, TransformStamped, callback)
		return







	# The main

if __name__ == '__main__':

		#runs the Goal() function
		Goal()



		# will loop as long as the code is not shutdown / ctl c
		while not rospy.is_shutdown():

			# preparing our converted information to be published on the node /Goal as a string
			pub = rospy.Publisher('/Goal', String, queue_size=1)

			# Publish the information
			pub.publish(position)

			# The code sleeps/waits 2 seconds
			rospy.sleep(2)